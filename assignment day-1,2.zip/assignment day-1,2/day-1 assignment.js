a="Name: Abhinav"
b="Age: 22"
console.log(a)
console.log(b)
document.write('hello guys')